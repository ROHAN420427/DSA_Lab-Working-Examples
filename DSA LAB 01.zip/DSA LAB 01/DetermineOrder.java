import java.util.Scanner;
public class DetermineOrder {
    public static void checkOrder(int num1 , int num2 , int num3)
    {
        if(num1 < num2 && num2 < num3)
        {
            System.out.println("increasing order");
        }else if(num1 > num2 && num2 > num3)
        {
            System.out.println("decreasing order");
        }else{
            System.out.println("neither increasing nor decreasing  order");
        }
    }
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("enter first number : ");
        int num1 = scanner.nextInt();
        System.out.print("enter second number : ");
        int num2 = scanner.nextInt();
        System.out.print("enter third number : ");
        int num3 = scanner.nextInt();
        checkOrder(num1, num2, num3);
        scanner.close();
    }
}