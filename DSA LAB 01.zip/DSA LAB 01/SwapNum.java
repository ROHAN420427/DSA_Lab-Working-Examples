public class SwapNum {
    int x ;
    int y ;
    SwapNum(int x , int y)
    {
        this.x = x;
        this.y = y;
    }
    public void swap( )
    {
        x = x + y;
        y = x - y;
        x = x - y;
        System.out.println("x = " +x+" and y is ="+y);
    }
    public static void main(String[] args) {
        int x=10;
        int y=55;
        SwapNum swapNum = new SwapNum(x, y);
        swapNum.swap();
    }
}