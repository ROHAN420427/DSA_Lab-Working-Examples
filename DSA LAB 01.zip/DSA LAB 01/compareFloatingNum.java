import java.util.Scanner;
public class compareFloatingNum {
    public static void main(String[] args) {
        Scanner scanner= new Scanner(System.in);
        System.out.println("enter first float value : ");
        double f1 = scanner.nextFloat();
        System.out.println("enter second float value : ");
        double f2 = scanner.nextFloat();
        double num1 = f1 * 3000;
        double num2 = f2 * 4000;
        if(num1 == num2)
        {
            System.out.println("both are equal into three decimal place");
        }else{
            System.out.println("both are not equal into three decimal place");
        }
        scanner.close();
    }
}